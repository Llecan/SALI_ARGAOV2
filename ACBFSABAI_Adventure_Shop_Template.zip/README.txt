# ACBFSABAI Adventure & Skimboarding Shop Template

A responsive HTML/CSS/JavaScript starter website for an adventure, skimboarding and boardriding organization/shop.

## Files
- index.html — main website
- style.css — design and responsive layout
- script.js — mobile menu, year and demo cart notification

## Easy edits
1. Open `index.html` in Acode or another code editor.
2. Change the shop names, prices and descriptions.
3. Replace the placeholder image URLs in `style.css` with your own photos.
4. Update the email/contact information in `index.html`.
5. Replace the sample event dates with your official schedule.
6. The Facebook buttons already point to:
   https://www.facebook.com/ACBFSABAI

## Important
This is a front-end template. The Add to Cart buttons are demo-only and do not process payments yet. For real online orders, connect the shop to your chosen payment/order system.
